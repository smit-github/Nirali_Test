/* tests/unit-test.h.  Generated from unit-test.h.in by configure.  */
/*
 * Copyright © 2008-2014 Stéphane Raimbault <stephane.raimbault@gmail.com>
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */


/* Constants defined by configure.ac */
#define HAVE_INTTYPES_H 1
#define HAVE_STDINT_H 1
#include <stdbool.h>

#ifdef HAVE_INTTYPES_H
#include <inttypes.h>
#endif
#ifdef HAVE_STDINT_H
# ifndef _MSC_VER
# include <stdint.h>
# else
# include "stdint.h"
# endif
#endif


typedef union 
{
	struct
	{	
		uint8_t Dataclass:2;//LSB
		uint8_t On_before_off:1;
		uint8_t unused:5;//MSB
	}bits;
	uint8_t DO_Bits;
}bitAllocation;




typedef union
{
	struct
	{
		uint8_t CASDU2;	//LSB
		uint8_t CASDU1;	//MSB			

		uint8_t IOA2;	//LSB
		uint8_t IOA1;	//MSB					

		uint8_t TI;	//LSB
		uint8_t IOA3;	//MSB

		uint16_t select_execute_t; 
		uint16_t default_on_t ;
		uint16_t output_t_1 ;
		uint16_t output_t_0;

	        bitAllocation DO_bitAllocation;		
		uint8_t Unused;

		uint8_t RS_mon_source_1 ;//LSB
		uint8_t RS_mon_source_0 ;//MSB

		uint16_t RS_mon_t;
		uint16_t command_prolong_t ;
		uint16_t TERM_t;
		uint16_t sync_t_0 ;
		uint16_t sync_t_1 ;
		uint16_t sync_inp_t_0 ;
		uint16_t sync_inp_t_1 ;

	} HPA;
	uint16_t HPA_DO_Per_Channel[16];
} DO_HARDWARE_POINT_PER_CHANNEL_ADDRESSES ;


typedef union
{
	struct
	{
		DO_HARDWARE_POINT_PER_CHANNEL_ADDRESSES HPA_DO_Per_Channel[8];
	} HPA_whole;
	uint16_t HPA_DO_Whole_Channel[128];
	
} DO_HARDWARE_POINT_ADDRESSES ;






//extern DI_HARDWARE_POINT_PER_CHANNEL_ADDRESSES DI_HPA_Data[16];
extern DO_HARDWARE_POINT_ADDRESSES DO_HPA_Data;


